script_info_shiny <- function() {
  server <- function(input, output) {

    result <- script_info(print=FALSE,result=TRUE)
    output$nb_commented <- renderText(result$nb_commented)
    output$nb_char <- renderText(result$nb_char)
    output$nb_uncommented <- renderText(result$nb_uncommented)

  }

  ui <- grid_page(
    tags$style(
    "p {
      font-size: 10px;
    }
    "
    ),
    layout = c(
      "header header header",
      "commented_l uncommented_l characters_l",
      "commented uncommented characters"
    ),
    row_sizes = c(
      "60px",
      "50px",
      "50px"
    ),
    col_sizes = c(
      "130px",
      "130px",
      "130px"
    ),
    gap_size = "15px",
    grid_card_text(
      area = "header",
      content = "Script info",
      alignment = "start",
      h_align = "start",
      is_title = TRUE
    ),
    grid_card_text(
      area = "commented_l",
      content = "Commented lines",
      alignment = "start",
      h_align = "start",
      is_title = FALSE,
      wrapping_tag = "p"
    ),
    grid_card_text(
      area = "uncommented_l",
      content = "Uncommented lines",
      alignment = "start",
      h_align = "start",
      is_title = FALSE,
      wrapping_tag = "p"
    ),
    grid_card_text(
      area = "characters_l",
      content = "Characters (uncommented, no spaces)",
      alignment = "start",
      h_align = "start",
      is_title = FALSE,
      wrapping_tag = "p"
    ),
    grid_card(
      area = "commented",
      textOutput(outputId = "nb_commented"),
      tags$head(tags$style("#nb_commented{color: blue;
                                 font-size: 10px;
            font-style: bold;
            }"))
    ),
    grid_card(
      area = "characters",
      textOutput(outputId = "nb_char"),
      tags$head(tags$style("#nb_char{color: blue;
                                 font-size: 10px;
            font-style: bold;
            }"))
    ),
    grid_card(
      area = "uncommented",
      textOutput(outputId = "nb_uncommented"),
      tags$head(tags$style("#nb_uncommented{color: blue;
                                 font-size: 10px;
            font-style: bold;
            }"))
    )
  )
  viewer <- paneViewer(300)
  runGadget(ui, server, viewer = viewer)
}
