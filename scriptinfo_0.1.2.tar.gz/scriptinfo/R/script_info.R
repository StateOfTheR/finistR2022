get_active_document_context <- function() {
  print(rstudioapi::getActiveDocumentContext())
}

get_text_lines_and_char <- function(script) {

  script <- script[script!=""]

  nb_commented <- sum(substr(script,1,1)=="#")
  nb_uncommented <- sum(substr(script,1,1)!="#")
  uncommented_script <- script[substr(script,1,1)!="#"]
  gsub(" ", "", paste(uncommented_script, collapse=""))
  nb_char <- sum(sapply(script, nchar))

  ret <- list("nb_commented" = nb_commented,
              "nb_uncommented" = nb_uncommented,
              "nb_char" = nb_char)

  return(ret)
}

script_info <- function(print=TRUE, result=FALSE) {

  context <- rstudioapi::getActiveDocumentContext()
  if (context$id == "#console") {
    script <- ""
  } else {
    script <- context$contents
  }
  ret <- get_text_lines_and_char(script)

  if (print == TRUE) {
    print(ret)
  }

  if (result == TRUE) {
    return(ret)
  }
}
